// Shared Aurelius sidebar. Add data-page="chat|cv|solver|youtube|expenses" to <body>.
// Expects an element with id="sidebar-root" where the sidebar will be inserted.
(function () {
  var TABS = [
    { id: 'dashboard', jack: 'DB', label: 'Dashboard',           href: 'dashboard.html' },
    { id: 'chat',     jack: 'CH', label: 'Normal Chat',        href: 'chat.html' },
    { id: 'cv',       jack: 'CV', label: 'CV Summarizer',      href: 'cv.html' },
    { id: 'solver',   jack: 'QS', label: 'Question Solver',    href: 'solver.html' },
    { id: 'youtube',  jack: 'YT', label: 'YouTube Summarizer', href: 'youtube.html' },
    { id: 'expense',  jack: 'EX', label: 'Expense Tracker',    href: 'expenses.html' }
  ];

  var active = document.body.getAttribute('data-page');

  var linksHtml = TABS.map(function (t) {
    var isActive = t.id === active;
    return (
      '<a href="' + t.href + '" id="nav-' + t.id + '" data-label="' + t.label.toLowerCase() + '"' +
      (isActive ? ' aria-current="page"' : '') +
      ' class="sidebar-tab flex items-center gap-4 px-4 py-4 transition-all ' +
        (isActive ? 'text-gold nav-item-active' : 'text-slate-500 hover:text-white group') + '">' +
        '<span class="w-6 h-6 flex items-center justify-center border ' +
          (isActive ? 'border-current' : 'border-slate-800 group-hover:border-gold transition-colors') +
          ' text-[9px] font-bold">' + t.jack + '</span>' +
        '<span class="text-sm tracking-wide font-medium">' + t.label + '</span>' +
      '</a>'
    );
  }).join('');

  var html =
    '<aside class="w-80 bg-[#0D1016] border-r border-[#1E232D] flex flex-col z-50 shrink-0">' +
      '<div class="p-10 pb-12 flex flex-col items-start">' +
        '<div class="flex items-center gap-3 mb-2">' +
          '<div class="w-8 h-8 rounded-full border border-gold flex items-center justify-center relative">' +
            '<div class="w-4 h-4 rounded-full bg-emerald-500 animate-pulse" id="aureliusStatusDot"></div>' +
            '<div class="absolute inset-0 border border-emerald-500/30 rounded-full scale-125" id="aureliusStatusRing"></div>' +
          '</div>' +
          '<span class="serif-font text-xl font-semibold tracking-wide text-white">Aurelius</span>' +
        '</div>' +
        '<span class="text-[10px] uppercase tracking-[0.4em] text-gold-muted font-bold ml-1">Executive Intelligence</span>' +
      '</div>' +

      '<div class="px-8 mb-8">' +
        '<div class="relative group">' +
          '<iconify-icon icon="lucide:search" class="absolute left-3 top-1/2 -translate-y-1/2 text-slate-600 group-focus-within:text-gold transition-colors"></iconify-icon>' +
          '<input type="text" id="sidebarSearch" placeholder="Access tools..." autocomplete="off" ' +
            'class="w-full bg-[#050608] border border-[#1E232D] rounded-none py-3 pl-10 pr-4 text-xs tracking-wider focus:outline-none focus:border-gold/40 transition-all">' +
        '</div>' +
      '</div>' +

      '<nav class="flex-1 overflow-y-auto custom-scrollbar px-6 space-y-4">' +
        '<div class="px-2 mb-2">' +
          '<span class="text-[9px] font-bold uppercase tracking-[0.3em] text-slate-600">Core Systems</span>' +
        '</div>' +
        linksHtml +
      '</nav>' +

      '<div class="p-8 border-t border-[#1E232D] space-y-4">' +
        '<button id="themeToggle" class="w-full flex items-center justify-between text-slate-500 hover:text-gold transition-colors">' +
          '<span class="flex items-center gap-3">' +
            '<iconify-icon icon="lucide:moon-star" id="themeIcon" class="text-base"></iconify-icon>' +
            '<span class="text-[10px] uppercase tracking-widest font-bold" id="themeLabel">Dark Mode</span>' +
          '</span>' +
          '<span class="w-11 h-6 rounded-full border border-[#1E232D] relative shrink-0 transition-colors duration-300" id="themeSwitchTrack">' +
            '<span class="absolute top-0.5 left-0.5 w-4.5 h-4.5 rounded-full bg-white shadow-md transition-transform duration-300" id="themeSwitchKnob" style="width:18px;height:18px;"></span>' +
          '</span>' +
        '</button>' +
        '<div class="flex items-center gap-3">' +
          '<span class="relative flex w-2 h-2">' +
            '<span class="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-500 opacity-60"></span>' +
            '<span class="relative inline-flex rounded-full w-2 h-2 bg-emerald-500 shadow-[0_0_8px_2px_rgba(16,185,129,0.6)]"></span>' +
          '</span>' +
          '<span class="text-[10px] uppercase tracking-widest text-slate-500 font-bold">Synchronized</span>' +
        '</div>' +
      '</div>' +
    '</aside>';

  document.addEventListener('DOMContentLoaded', function () {
    var root = document.getElementById('sidebar-root');
    if (root) root.outerHTML = html;

    // Sync the toggle's visual state now that its markup exists in the DOM.
    window.Aurelius.setTheme(localStorage.getItem('aureliusTheme') === 'light' ? 'light' : 'dark');

    var searchInput = document.getElementById('sidebarSearch');
    if (searchInput) {
      searchInput.addEventListener('input', function () {
        var q = searchInput.value.trim().toLowerCase();
        document.querySelectorAll('.sidebar-tab').forEach(function (tab) {
          var matches = tab.getAttribute('data-label').indexOf(q) !== -1;
          tab.style.display = matches ? '' : 'none';
        });
      });
    }

    // Once an error fires anywhere, the logo stays orange for the rest of the session
    // (sessionStorage survives page navigation within the app, so redirects don't reset it).
    if (sessionStorage.getItem('aureliusStatus') === 'error') {
      window.Aurelius.setStatus('error');
    }

    var themeToggle = document.getElementById('themeToggle');
    if (themeToggle) {
      themeToggle.addEventListener('click', function () {
        var isLight = document.documentElement.getAttribute('data-theme') === 'light';
        window.Aurelius.setTheme(isLight ? 'dark' : 'light');
      });
    }
  });

  // Global theme API — persists across pages via localStorage.
  window.Aurelius = window.Aurelius || {};
  window.Aurelius.setTheme = function (mode) {
    document.documentElement.setAttribute('data-theme', mode);
    localStorage.setItem('aureliusTheme', mode);
    var icon = document.getElementById('themeIcon');
    var label = document.getElementById('themeLabel');
    var knob = document.getElementById('themeSwitchKnob');
    var track = document.getElementById('themeSwitchTrack');
    if (icon) icon.setAttribute('icon', mode === 'light' ? 'lucide:sun' : 'lucide:moon-star');
    if (label) label.textContent = mode === 'light' ? 'Light Mode' : 'Dark Mode';
    if (knob) knob.style.transform = mode === 'light' ? 'translateX(20px)' : 'translateX(0)';
    if (track) track.style.background = mode === 'light' ? 'rgba(166,124,61,0.35)' : '#050608';
  };

  // Apply saved theme immediately (before sidebar markup even loads) to avoid a flash.
  window.Aurelius.setTheme(localStorage.getItem('aureliusTheme') === 'light' ? 'light' : 'dark');

  // Shared typing/streaming effect: reveals text into an element a few characters at a time.
  // Used to simulate streaming since the n8n webhooks return the full reply in one shot.
  window.Aurelius.typeText = function (el, text, speed) {
    return new Promise(function (resolve) {
      el.textContent = '';
      var i = 0;
      var step = speed || 12;
      var timer = setInterval(function () {
        i += 2;
        el.textContent = text.slice(0, i);
        if (typeof window.Aurelius.onType === 'function') window.Aurelius.onType();
        if (i >= text.length) {
          clearInterval(timer);
          el.textContent = text;
          resolve();
        }
      }, step);
    });
  };

  // Shared "processing" bubble for chat-style pages (chat.html, expenses.html, cv.html).
  // Appends a dim bubble with pulsing dots into `container`, matching the given icon,
  // and returns a function that removes it once the real reply arrives.
  window.Aurelius.addPendingEntry = function (container, iconName) {
    var wrap = document.createElement('div');
    wrap.className = 'flex items-start gap-4 group animate-reveal';
    wrap.innerHTML =
      '<div class="w-9 h-9 border border-gold/30 bg-[#0D1016] flex items-center justify-center shrink-0 shadow-2xl relative overflow-hidden">' +
        '<div class="absolute inset-0 bg-gold/5"></div>' +
        '<iconify-icon icon="' + (iconName || 'lucide:bot-message-square') + '" class="text-gold text-base relative z-10"></iconify-icon>' +
      '</div>' +
      '<div class="space-y-2 max-w-2xl pt-2">' +
        '<div class="typing-dots"><span></span><span></span><span></span></div>' +
      '</div>';
    container.appendChild(wrap);
    return function remove() { wrap.remove(); };
  };

  // Shared error state with retry: renders a message + retry icon into `el`, and calls
  // `retryFn` (which should itself set el's content again on success/failure) on click.
  window.Aurelius.errorWithRetry = function (el, message, retryFn) {
    el.classList.remove('flex', 'items-center', 'gap-2');
    el.innerHTML =
      '<span class="flex items-center gap-2 text-slate-500">' +
        '<iconify-icon icon="lucide:alert-circle" class="text-amber-500/70"></iconify-icon>' +
        '<span>' + message + '</span>' +
        '<button type="button" class="aurelius-retry-btn inline-flex items-center gap-1 ml-1 text-[10px] uppercase tracking-widest font-bold text-gold-muted hover:text-gold transition-colors">' +
          '<iconify-icon icon="lucide:refresh-cw"></iconify-icon>Retry' +
        '</button>' +
      '</span>';
    var btn = el.querySelector('.aurelius-retry-btn');
    if (btn && typeof retryFn === 'function') {
      btn.addEventListener('click', function () {
        var icon = btn.querySelector('iconify-icon');
        if (icon) icon.classList.add('animate-spin');
        btn.disabled = true;
        retryFn();
      });
    }
  };

  // Global status API: call Aurelius.setStatus('ok' | 'error') from any page.
  // 'ok'    -> logo glows green (all tools reachable)
  // 'error' -> logo glows orange (something failed) and stays that way across pages this session
  window.Aurelius = window.Aurelius || {};
  window.Aurelius.setStatus = function (state) {
    var dot = document.getElementById('aureliusStatusDot');
    var ring = document.getElementById('aureliusStatusRing');
    if (!dot || !ring) return;
    if (state === 'error') {
      dot.classList.remove('bg-emerald-500');
      dot.classList.add('bg-amber-500');
      ring.classList.remove('border-emerald-500/30');
      ring.classList.add('border-amber-500/30');
      sessionStorage.setItem('aureliusStatus', 'error');
    } else {
      dot.classList.remove('bg-amber-500');
      dot.classList.add('bg-emerald-500');
      ring.classList.remove('border-amber-500/30');
      ring.classList.add('border-emerald-500/30');
      sessionStorage.removeItem('aureliusStatus');
    }
  };
})();
